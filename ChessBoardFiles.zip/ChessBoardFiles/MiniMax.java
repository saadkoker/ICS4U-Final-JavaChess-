public class MiniMax{
	
}